<div class="col-md-6 col-md-offset-4">
	<img class="img-responsive" style="margin-top:30%"src="<?=base_url()?>img/restriccion.jpg">
</div>