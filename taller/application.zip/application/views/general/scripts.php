<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

 	
 	
 	<script src="https://datatables.net/release-datatables/media/js/jquery.js"></script>
	<script type="text/javascript" src="https://datatables.net/release-datatables/media/js/jquery.dataTables.js"></script>
	<script src="https://datatables.net/release-datatables/extensions/TableTools/js/dataTables.tableTools.js"></script>
	<script src="https://datatables.net/release-datatables/extensions/Plugins/integration/bootstrap/3/dataTables.bootstrap.js"></script>
	<script src="<?=base_url()?>js/editar.js"></script>
	
	
<!-- Include all compiled plugins (below), or include individual files as needed -->
 	<script src="<?=base_url()?>js/bootstrap.min.js"></script>
	<!--link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css"--sabe se ocupe-->
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
	<script>
		$(document).on('ready',function(){
			 $(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
		});

	</script>
	
	